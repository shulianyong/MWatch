//
//  STBPlayer.h
//  STB
//
//  Created by shulianyong on 13-10-13.
//  Copyright (c) 2013年 Chengdu Sifang Information Technology Co.LTD. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MovieViewDelegate.h"

@interface STBPlayer : UIView<MovieViewProtocol>

@end

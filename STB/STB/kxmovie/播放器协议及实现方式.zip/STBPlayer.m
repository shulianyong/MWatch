//
//  STBPlayer.m
//  STB
//
//  Created by shulianyong on 13-10-13.
//  Copyright (c) 2013年 Chengdu Sifang Information Technology Co.LTD. All rights reserved.
//

#import "STBPlayer.h"
#import <MediaPlayer/MediaPlayer.h>
#import <QuartzCore/QuartzCore.h>
#import "KxMovieDecoder.h"
#import "KxAudioManager.h"
#import "KxMovieGLView.h"

@interface STBPlayer ()
{
    
    CGFloat             _moviePosition;
}

//播放器的openGL用于渲染的界面
@property (strong,nonatomic) KxMovieGLView *playerView;

@end

@implementation STBPlayer

//路径，由使用者给
@synthesize channelPath;

//委托对象，由使用者给
@synthesize movieDelegate;

#pragma mark --------------------- 公共方法

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        // Initialization code
        //初始化播放开启时，需要的东西
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        //初始化播放开启时，需要的东西
    }
    return self;
}

#pragma mark 设置播放器位置

//设置播放器界面的长，度，位置
- (void)configScreenFrame:(CGRect)aFrame
{
    self.frame = aFrame;
    
    CGRect playerFrame = aFrame;
    playerFrame.origin.x = 0;
    playerFrame.origin.y = 0;
    self.playerView.frame = playerFrame;
}

- (void) setupPresentView
{
    //设置 播放器的界面
    CGRect bounds = self.bounds;
    KxMovieDecoder      *_decoder;
    self.playerView = [[KxMovieGLView alloc] initWithFrame:bounds decoder:_decoder];
    self.playerView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleBottomMargin;
}

//界面加载
- (void)layoutSubviews
{
    [super layoutSubviews];
    
    //设置 播放器的界面
    [self setupPresentView];
}

#pragma mark ----------------------播放控制

//根据 channelPath，进行播放，
//相当于    - (id) initWithContentPath: (NSString *) path
//parameters: (NSDictionary *) parameters
- (void)play
{
    
//    加载网络视频时，需要告诉用户，已经加载 百分之几了，如20%
    [self.movieDelegate loading:@"20%"];
    
    //数据加载完成，准备播放时，通知用户，现在在播放了
    [self.movieDelegate loadend];
    
    //播放过程中，如遇到错误，发起错识提醒，回调错识提醒代码,如网络断联
    [self.movieDelegate fail:NetworkDisconnetionType];    
}

- (void)pause
{
    //暂停播放
}

- (void)stop
{
    //停止播放
}


//快起，或者是后退
//aPosition参数，是快进，或者后退秒数
- (void)setMoviePosition:(CGFloat)aPosition
{
    CGFloat position = _moviePosition + 10;
//    BOOL playMode = self.playing;
//    
//    self.playing = NO;
//    _disableUpdateHUD = YES;
//    [self enableAudio:NO];
//    
//    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, 0.1 * NSEC_PER_SEC);
//    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
//        
//        [self updatePosition:position playMode:playMode];
//    });
    
}

#pragma mark ---------------------- 私有方法

@end


